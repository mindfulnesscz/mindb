#!/usr/bin/env node
/* Move an environment's asset objects into the two-tier layout.
 *
 *   public   effective_level = 'public'  -> stays in the PUBLIC bucket, key unchanged
 *   gated    everything else             -> copied to the GATED bucket under {level}/{client_id}/…
 *
 * Where an object belongs is decided by `packages/domain/src/assetStorage.ts`, imported directly
 * rather than restated here — the pipeline uses the same module, so the two cannot drift into
 * writing objects to one place and looking for them in another.
 *
 * THREE PROPERTIES THIS HAS TO HAVE, because it moves other people's files:
 *
 *   idempotent   it compares each row's stored URL against the computed target and skips what
 *                already matches, so a re-run after an interruption resumes rather than repeats.
 *   reversible   copy and repoint FIRST; the source object is left in place. Nothing 404s if the
 *                result is wrong — rollback is repointing the URLs back. `--delete-source` is a
 *                SEPARATE later pass, and it is the only irreversible step.
 *   loud         dry run is the default. `--execute` is required to change anything.
 *
 * A URL that has already been published cannot be un-published. Objects that were public stay
 * fetchable at their old address until --delete-source runs, and anyone who already copied the URL
 * keeps the bytes regardless. Re-keying limits future exposure; it does not undo past exposure.
 *
 *   node scripts/rekey-gated-objects.mjs staging                     # dry run, changes nothing
 *   node scripts/rekey-gated-objects.mjs staging --raise-to-client   # preview the perm change too
 *   node scripts/rekey-gated-objects.mjs staging --execute
 *   node scripts/rekey-gated-objects.mjs staging --execute --delete-source   # after verifying
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { effectiveLevel, tierFor, assetUrl, stripVersion, pagePrefix } =
  await import(path.join(root, 'packages/domain/src/assetStorage.ts'));

/* ── args ──────────────────────────────────────────────────────────────────── */

const args = process.argv.slice(2);
const envName = args.find(a => !a.startsWith('--'));
const has = f => args.includes(f);
const EXECUTE = has('--execute');
const DELETE_SOURCE = has('--delete-source');
const RECLASSIFY = has('--raise-to-client') || has('--reclassify-public'); // old name kept working

if (!envName) {
  console.error('usage: node scripts/rekey-gated-objects.mjs <env> [--raise-to-client] [--execute] [--delete-source]');
  process.exit(1);
}

/* Config is layered, lowest precedence first:
     1. <env>.public.env   COMMITTED. Project ref, bucket names, public hostnames — every one of
                           them already visible in a browser or in wrangler.jsonc, so keeping them
                           in the repo costs nothing and means CI needs only the real secrets.
     2. <env>.env          gitignored. The four actual secrets, for local runs.
     3. the process        what CI supplies.
   One code path serves a laptop and a GitHub runner, which is the point: a second path is a second
   thing to get right, and this one moves client files. */
const readEnvFile = (file) => fs.existsSync(file)
  ? Object.fromEntries(
      fs.readFileSync(file, 'utf8').split('\n')
        .filter(l => l.trim() && !l.startsWith('#') && l.includes('='))
        .map(l => [l.slice(0, l.indexOf('=')).trim(), l.slice(l.indexOf('=') + 1).trim()]),
    )
  : {};

const publicFile = path.join(root, 'scripts/environments', `${envName}.public.env`);
const envFile    = path.join(root, 'scripts/environments', `${envName}.env`);
const env = {
  ...readEnvFile(publicFile),
  ...readEnvFile(envFile),
  ...Object.fromEntries(Object.entries(process.env).filter(([, v]) => v !== undefined && v !== '')),
};

/* CF_R2_TOKEN was CF_API_TOKEN. Applied BEFORE the required-keys check below, or that check
   reports a token missing that the fallback was about to supply. */
env.CF_R2_TOKEN ??= env.CF_API_TOKEN;

/* Every value is named explicitly, including the gated pair. An earlier draft derived the gated
   bucket from the public one and got it wrong — `dc-hub-staging` would have produced
   `dc-hub-staging-gated`, while the bucket that exists is `dc-hub-gated-staging`. A clever
   derivation that is wrong writes objects into a bucket nobody is serving. */
const need = ['PROJECT_REF', 'SUPABASE_SERVICE_KEY', 'R2_BUCKET', 'R2_PUBLIC_DOMAIN',
              'R2_GATED_BUCKET', 'R2_GATED_DOMAIN',
              'CF_R2_TOKEN', 'CF_ACCOUNT_ID', 'R2_PARENT_ACCESS_KEY_ID'];
const missing = need.filter(k => !env[k] || String(env[k]).startsWith('PASTE_'));
if (missing.length) {
  console.error(`Missing for "${envName}": ${missing.join(', ')}`);
  /* "missing" is the truth but not always the cause. An empty or absent file reads exactly like a
     file whose keys are wrong, and the first costs someone a while re-checking key names that were
     never there — so say which it is. */
  const secretsRead = Object.keys(readEnvFile(envFile)).length;
  if (!fs.existsSync(envFile)) {
    console.error(`\n  ${path.relative(root, envFile)} does not exist.`);
  } else if (secretsRead === 0) {
    console.error(`\n  ${path.relative(root, envFile)} exists but is EMPTY — unsaved edit?`);
  }
  const placeholder = Object.entries(env).filter(([, v]) => String(v).startsWith('PASTE_'));
  if (placeholder.length) {
    console.error(`  still holding a placeholder: ${placeholder.map(([k]) => k).join(', ')}`);
  }
  console.error(`\n  Non-secret values belong in ${path.relative(root, publicFile)} (committed);`);
  console.error(`  secrets in ${path.relative(root, envFile)} (gitignored) or the environment.`);
  process.exit(1);
}

const GATED_BUCKET = env.R2_GATED_BUCKET;
const GATED_DOMAIN = env.R2_GATED_DOMAIN;

const REST = `https://${env.PROJECT_REF}.supabase.co/rest/v1`;
const sbHeaders = {
  apikey: env.SUPABASE_SERVICE_KEY,
  Authorization: `Bearer ${env.SUPABASE_SERVICE_KEY}`,
  'Content-Type': 'application/json',
};

/* ── R2 over the S3 API, signed with short-lived credentials ──────────────────
   Same mechanism the r2-grant edge function uses: the Cloudflare API mints a temporary,
   bucket-scoped key pair from the parent key. Nothing long-lived is written down here. */

async function tempCredentials(bucket) {
  const res = await retryFetch(
    `https://api.cloudflare.com/client/v4/accounts/${env.CF_ACCOUNT_ID}/r2/temp-access-credentials`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.CF_R2_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bucket, parentAccessKeyId: env.R2_PARENT_ACCESS_KEY_ID,
        permission: 'object-read-write', ttlSeconds: 3600,
      }),
    },
  );
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.result?.accessKeyId) {
    throw new Error(`temp credentials for ${bucket}: ${res.status} ${JSON.stringify(body?.errors ?? body)}`);
  }
  return body.result;
}

/* A thousand-object run touches the network thousands of times; one blip should not end it. The
   S3 path re-signs per attempt (see s3), so this wrapper is for everything else: the Cloudflare
   credential mint and the Supabase reads and writes, each of which ended a run outright. */
async function retryFetch(url, init, attempts = 3) {
  let lastErr;
  for (let i = 1; i <= attempts; i++) {
    try { return await fetch(url, init); }
    catch (e) { lastErr = e; if (i < attempts) await new Promise(r => setTimeout(r, i * 1500)); }
  }
  throw lastErr;
}

const sha256hex = b => crypto.createHash('sha256').update(b).digest('hex');
const hmac = (k, s) => crypto.createHmac('sha256', k).update(s).digest();

/* SigV4 canonicalises paths per RFC 3986, where the unreserved set is only A–Z a–z 0–9 - _ . ~
   `encodeURIComponent` leaves !'()* alone, so a key containing parentheses signed cleanly on this
   side and hashed differently on Cloudflare's — an opaque 403 that reads as a permissions fault.
   It cost 17 objects on the production run: legacy filename-keyed thumbnails such as
   `(p-SpW)(ILL)(TrpB) 3D Vis v3-0-0-thumb.webp`, which are exactly the ones full of brackets. */
const rfc3986 = str => encodeURIComponent(str)
  .replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());

/** Minimal SigV4 for R2. Only the three verbs this script needs. */
async function s3(creds, bucket, method, key, body = null, extraHeaders = {}, query = {}) {
  const host = `${env.CF_ACCOUNT_ID}.r2.cloudflarestorage.com`;
  const payloadHash = sha256hex(body ?? Buffer.alloc(0));
  const canonicalUri = `/${bucket}/${key.split('/').map(rfc3986).join('/')}`;
  /* SigV4 requires the query sorted by key and rfc3986-encoded. An empty query yields '', which is
     exactly what the copy/delete paths signed before this parameter existed — so they are unchanged. */
  const canonicalQuery = Object.keys(query).sort()
    .map(k => `${rfc3986(k)}=${rfc3986(String(query[k]))}`).join('&');

  /* Signed INSIDE the retry loop, not once above it.
     A signature is stamped with the moment it was made, and R2 rejects anything more than a few
     minutes adrift with `RequestTimeTooSkewed` — a 403, indistinguishable at a glance from a
     credentials problem. Re-using one timestamp across retries meant a large upload that failed
     slowly was retried with a stale stamp and refused for a reason that had nothing to do with
     the retry. Each attempt now carries its own. */
  let lastErr;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const amzDate = new Date().toISOString().replace(/[:-]|\.\d{3}/g, '');
    const dateStamp = amzDate.slice(0, 8);

    // Lowercase keys throughout, so the canonical form is a plain sort of this object rather than
    // a case-insensitive lookup back into it. SigV4 fails opaquely (403) when the signed list and
    // the sent headers disagree by so much as capitalisation.
    const headers = {
      host,
      'x-amz-content-sha256': payloadHash,
      'x-amz-date': amzDate,
      'x-amz-security-token': creds.sessionToken,
      ...Object.fromEntries(Object.entries(extraHeaders).map(([k, v]) => [k.toLowerCase(), v])),
    };
    const signedNames = Object.keys(headers).sort();
    const canonicalHeaders = signedNames.map(h => `${h}:${String(headers[h]).trim()}\n`).join('');
    const signedHeaders = signedNames.join(';');

    const canonical = [method, canonicalUri, canonicalQuery, canonicalHeaders, signedHeaders, payloadHash].join('\n');
    const scope = `${dateStamp}/auto/s3/aws4_request`;
    const toSign = ['AWS4-HMAC-SHA256', amzDate, scope, sha256hex(Buffer.from(canonical))].join('\n');
    const kDate = hmac(`AWS4${creds.secretAccessKey}`, dateStamp);
    const signature = hmac(hmac(hmac(hmac(kDate, 'auto'), 's3'), 'aws4_request'), toSign).toString('hex');

    headers.Authorization =
      `AWS4-HMAC-SHA256 Credential=${creds.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    try {
      const url = `https://${host}${canonicalUri}${canonicalQuery ? `?${canonicalQuery}` : ''}`;
      return await fetch(url, { method, headers, body: body ?? undefined });
    } catch (e) {
      lastErr = e;
      if (attempt < 3) await new Promise(r => setTimeout(r, attempt * 1500));
    }
  }
  throw lastErr;
}

/* ── the work ─────────────────────────────────────────────────────────────── */

/* Must match parseGatedKey in workers/cdn-gate/src/authz.ts — the Worker restates this shape by
   hand because it is a separate deployment, so the two are checked against each other here. */
const GATED_KEY_SHAPE =
  /^(public|guest|client|internal)\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\/.+/i;

const log = (...a) => console.log(...a);
const plan = { skip: 0, copy: 0, repoint: 0, del: 0, missing: 0, failed: 0 };

async function main() {
  log(`\n  environment   ${envName}  (${env.PROJECT_REF})`);
  log(`  public        ${env.R2_BUCKET}  ${env.R2_PUBLIC_DOMAIN}`);
  log(`  gated         ${GATED_BUCKET}  ${GATED_DOMAIN}`);
  log(`  mode          ${EXECUTE ? 'EXECUTE' : 'DRY RUN — nothing will change'}${DELETE_SOURCE ? ' + DELETE SOURCE' : ''}\n`);

  /* Step 0 — raise the floor to `client`: readable by members of the owning client and above.
     Assets written before 2026-07-31 carry perm='public' because the pipeline hardcoded it, not
     because anyone decided they should be world-readable, and without this the overwhelming
     majority of objects stay on the public domain and the re-key means little.

     NARROWING ONLY, and both halves of that matter. `public` and `guest` are below the floor and
     are raised to it; `client` is already there; `internal` is ABOVE it and is left alone, because
     a sweep that loosened an asset someone had deliberately locked down would be the one mistake
     this whole exercise exists to prevent.

     Separate flag, because it changes who can SEE things rather than merely where bytes live —
     and it is never passed by the scheduled reconciler. */
  const BELOW_FLOOR = ['public', 'guest'];
  if (RECLASSIFY) {
    const filter = `perm=in.(${BELOW_FLOOR.join(',')})`;
    const below = await sbGet(`/assets?select=id,perm&${filter}`);
    const byPerm = BELOW_FLOOR
      .map(p => `${below.filter(r => r.perm === p).length} ${p}`).join(' + ');
    log(`  raise to client   ${below.length} row(s) (${byPerm}) -> client`);
    if (EXECUTE && below.length) {
      const res = await retryFetch(`${REST}/assets?${filter}`, {
        method: 'PATCH', headers: { ...sbHeaders, Prefer: 'return=minimal' },
        body: JSON.stringify({ perm: 'client' }),
      });
      if (!res.ok) throw new Error(`raise-to-client failed: ${res.status} ${await res.text()}`);
      log('                    done\n');
    } else log('');
  }

  const assets = await sbGet(
    '/assets?select=id,client_id,stable_id,child_id,perm,status,thumbnail_url,download_url&order=id',
  );

  /* On --execute the reclassification above has already landed, so these rows come back with the
     new perm and the plan below is built from reality. On a DRY RUN it has not, so the same rows
     would still read `public` and the preview would promise 54 reclassifications and then plan
     nine moves — a preview that does not resemble the run it is previewing is worse than none.
     Apply it in memory so the numbers shown are the numbers you would get. */
  if (RECLASSIFY && !EXECUTE) {
    for (const a of assets) if (BELOW_FLOOR.includes(a.perm)) a.perm = 'client';
  }
  log(`  ${assets.length} asset row(s)\n`);

  /* Credentials expire after an hour, and a full production re-key is ~1000 objects including
     multi-hundred-megabyte video. Minting once at the start meant a long run died partway through
     with 403s that look like a permissions fault rather than an expiry — and while the script is
     resumable, that is a bad half hour for whoever is watching it.
     Re-minted well inside the window, before each copy. */
  let creds = { public: await tempCredentials(env.R2_BUCKET), gated: await tempCredentials(GATED_BUCKET), mintedAt: Date.now() };
  const CRED_REFRESH_MS = 45 * 60 * 1000;   // TTL is 60 min; refresh with a quarter of it to spare
  async function freshCreds() {
    if (Date.now() - creds.mintedAt < CRED_REFRESH_MS) return creds;
    creds = {
      public: await tempCredentials(env.R2_BUCKET),
      gated: await tempCredentials(GATED_BUCKET),
      mintedAt: Date.now(),
    };
    log('  ⟳  storage credentials refreshed');
    return creds;
  }
  const bucketFor = tier => (tier === 'public' ? env.R2_BUCKET : GATED_BUCKET);
  const domainFor = tier => (tier === 'public' ? env.R2_PUBLIC_DOMAIN : GATED_DOMAIN);

  for (const a of assets) {
    if (!a.stable_id || !a.child_id || !a.client_id) continue; // no identity, no address
    const level = effectiveLevel(a);
    const patch = {};

    for (const column of ['thumbnail_url', 'download_url']) {
      const current = a[column];
      if (!current) continue;

      const source = { bucket: bucketOf(current), key: keyOf(current) };
      if (!source.key) { plan.failed++; log(`  ?  ${a.id} ${column}: cannot parse ${current}`); continue; }

      /* A migration MOVES bytes between tiers. It does not rename them.
         The obvious implementation — derive the target key from the row's stable_id/child_id, the
         way the pipeline does — is wrong here, and the dry run proved it: rows exist whose stored
         URL disagrees with their identity (a URL ending `/c2.webp` on a row whose child_id is
         `c1`), left over from earlier pipeline versions. Recomputing would have copied one object
         onto another object's key, silently overwriting it.
         So the key tail is preserved exactly and only the level prefix changes. That is
         collision-free by construction, and the pipeline converges keys back to identity on its
         next run, where a wrong key is a re-upload rather than a lost file. */
      const currentTier = source.bucket === env.R2_BUCKET ? 'public' : 'gated';
      const bare = source.key.replace(/^(public|guest|client|internal)\//, '');

      /* The gated key must be `{level}/{client_id}/…` — the Worker reads the client out of the
         second segment to decide tenant access, without a lookup. Objects from before the
         per-client prefix carry keys like `thumbnails/{stable}/{child}.webp` with no client at
         all, and simply prefixing the level yields `client/thumbnails/…`, which the Worker cannot
         parse and refuses with a 404. It fails closed, which is right, but the file is then
         unreachable. So the client id is inserted when the key lacks it. */
      const withClient = bare.startsWith(`${a.client_id}/`) ? bare : `${a.client_id}/${bare}`;
      const targetTier = tierFor(level);
      const targetKey = targetTier === 'public' ? bare : `${level}/${withClient}`;

      /* Refuse to write a key the gate cannot serve. This is the assertion that should have
         existed before a single byte moved: it is cheap, it is exact, and its absence let 9
         production objects land at unreachable addresses before anyone noticed. */
      if (targetTier === 'gated' && !GATED_KEY_SHAPE.test(targetKey)) {
        plan.failed++;
        log(`  ✕  ${a.id} ${column}: refusing unservable key ${targetKey}`);
        continue;
      }

      if (currentTier === targetTier && source.key === targetKey) { plan.skip++; continue; }

      const target = { tier: targetTier, key: targetKey };
      log(`  ${EXECUTE ? '→' : '·'}  ${level.padEnd(8)} ${currentTier}:${source.key}`);
      log(`     ${' '.repeat(9)}-> ${target.tier}:${target.key}`);

      if (EXECUTE) {
        const moved = await copyObject(await freshCreds(), source, { bucket: bucketFor(target.tier), key: target.key });
        if (moved === 'missing') { plan.missing++; continue; }
        if (moved === 'failed') { plan.failed++; continue; }
        plan.copy++;
        // The stamp is re-derived from the bytes actually copied, so the new URL busts caches
        // correctly even if the old URL's stamp was stale.
        patch[column] = assetUrl(domainFor(target.tier), target.key, moved);
      } else {
        plan.copy++;
      }
    }

    if (EXECUTE && Object.keys(patch).length) {
      const res = await retryFetch(`${REST}/assets?id=eq.${a.id}`, {
        method: 'PATCH', headers: { ...sbHeaders, Prefer: 'return=minimal' }, body: JSON.stringify(patch),
      });
      if (!res.ok) { plan.failed++; log(`  ✕  ${a.id}: DB update failed ${res.status} ${await res.text()}`); continue; }
      plan.repoint++;
    }
  }

  /* ── Page previews ─────────────────────────────────────────────────────────
     Found by LISTING, not by reading a URL column, because there is no page URL column: a document
     publishes one object per rendered page, so the portal derives each address from the asset's
     thumbnail URL instead of storing fifty of them.

     That is exactly why this pass has to exist. Everything above moves objects named by
     `thumbnail_url` / `download_url`; page objects are invisible to it. Without this, narrowing a
     deck from `client` to `internal` would leave its pages readable under the old `client/` prefix —
     a leak of the deck's content that nothing else heals. The desktop pipeline sweeps them on its
     next run, but a perm change made in the portal must not depend on someone running a pipeline.

     Unlike the URL columns there is no stored address to preserve, so the level prefix is swapped and
     the tail kept — the same collision-free rule documented above. Nothing is written back to the
     database: the portal recomputes page addresses from the thumbnail, which this pass has already
     repointed. */
  log('\n  page previews (listed, not column-driven)');
  for (const a of assets) {
    if (!a.stable_id || !a.child_id || !a.client_id) continue;
    const level = effectiveLevel(a);
    const targetTier = tierFor(level);

    for (const from of LEVELS) {
      const prefix = pagePrefix(from, a.client_id, a.stable_id, a.child_id);
      const fromTier = tierFor(from);
      let keys;
      try {
        keys = await listKeys(await freshCreds(), bucketFor(fromTier), prefix);
      } catch (e) {
        plan.failed++;
        log(`  ✕  ${a.id} pages: list ${prefix} failed — ${e.message}`);
        continue;
      }
      for (const key of keys) {
        // Same tail, target level prefix. `pagePrefix` puts the level first for gated keys and
        // omits it for public ones, so stripping a leading level is enough to get the bare tail.
        const bare = key.replace(/^(public|guest|client|internal)\//, '');
        const targetKey = targetTier === 'public' ? bare : `${level}/${bare}`;

        if (from === level && key === targetKey) { plan.skip++; continue; }
        if (targetTier === 'gated' && !GATED_KEY_SHAPE.test(targetKey)) {
          plan.failed++;
          log(`  ✕  ${a.id} pages: refusing unservable key ${targetKey}`);
          continue;
        }

        log(`  ${EXECUTE ? '→' : '·'}  ${level.padEnd(8)} ${fromTier}:${key}`);
        log(`     ${' '.repeat(9)}-> ${targetTier}:${targetKey}`);
        if (!EXECUTE) { plan.copy++; continue; }

        const moved = await copyObject(
          await freshCreds(),
          { bucket: bucketFor(fromTier), key },
          { bucket: bucketFor(targetTier), key: targetKey },
        );
        if (moved === 'missing') { plan.missing++; continue; }
        if (moved === 'failed') { plan.failed++; continue; }
        plan.copy++;

        /* Deleted HERE rather than in the --delete-source pass below, which decides what is
           superseded by checking the URL columns — page objects appear in none of them, so it would
           never delete one, and the stale copy at the old level is the leak. Guarded on the key
           having actually changed, so this can never delete what was just written. */
        if (key !== targetKey || fromTier !== targetTier) {
          const c = await freshCreds();
          const res = await s3(fromTier === 'public' ? c.public : c.gated, bucketFor(fromTier), 'DELETE', key);
          if (res.ok || res.status === 404) plan.del++; else plan.failed++;
        }
      }
    }
  }

  /* Deletion is a SEPARATE pass on purpose. By the time it runs, every row already points at the
     new object, so a source delete cannot break a live URL — and until it runs, the whole move is
     undone by repointing the URLs back. */
  if (DELETE_SOURCE) {
    log('\n  --delete-source: removing originals that have been superseded');
    if (!EXECUTE) log('  (dry run — listing only)');
    const after = await sbGet('/assets?select=id,thumbnail_url,download_url');
    const live = new Set(after.flatMap(r => [r.thumbnail_url, r.download_url].filter(Boolean).map(stripVersion)));
    for (const a of assets) {
      for (const column of ['thumbnail_url', 'download_url']) {
        const old = a[column];
        if (!old || live.has(stripVersion(old))) continue; // still referenced — never delete
        const src = { bucket: bucketOf(old), key: keyOf(old) };
        if (!src.key) continue;
        log(`  ${EXECUTE ? '✕' : '·'}  delete ${src.bucket}:${src.key}`);
        if (EXECUTE) {
          const c = await freshCreds();
          const res = await s3(c[src.bucket === env.R2_BUCKET ? 'public' : 'gated'], src.bucket, 'DELETE', src.key);
          if (res.ok || res.status === 404) plan.del++; else plan.failed++;
        } else plan.del++;
      }
    }
  }

  log(`\n  ${EXECUTE ? 'done' : 'would'}: ${plan.copy} copied · ${plan.repoint} rows repointed · `
    + `${plan.skip} already correct · ${plan.del} source deleted · ${plan.missing} source missing · ${plan.failed} failed`);
  if (!EXECUTE) log('  Nothing changed. Re-run with --execute.\n');
  if (plan.failed) process.exitCode = 1;
}

/** Every level an object could be sitting under, for the page sweep. */
const LEVELS = ['public', 'guest', 'client', 'internal'];

/**
 * Every key under `prefix`, following continuation tokens.
 *
 * Paginated deliberately rather than trusting one response: R2 caps a listing at 1000 keys, and a
 * 500-page document plus its siblings passes that. A truncated listing would silently leave objects
 * behind at the old level, which is the exact failure this pass exists to prevent.
 */
async function listKeys(creds, bucket, prefix) {
  const cred = bucket === env.R2_BUCKET ? creds.public : creds.gated;
  const out = [];
  let token;
  do {
    const query = { 'list-type': '2', prefix, 'max-keys': '1000', ...(token ? { 'continuation-token': token } : {}) };
    const res = await s3(cred, bucket, 'GET', '', null, {}, query);
    if (!res.ok) throw new Error(`list ${bucket}/${prefix} → ${res.status}`);
    const xml = await res.text();
    for (const m of xml.matchAll(/<Key>([^<]+)<\/Key>/g)) {
      out.push(m[1].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'));
    }
    token = /<IsTruncated>true<\/IsTruncated>/.test(xml)
      ? xml.match(/<NextContinuationToken>([^<]+)<\/NextContinuationToken>/)?.[1]
      : undefined;
  } while (token);
  return out;
}

async function copyObject(creds, source, target) {
  const from = source.bucket === env.R2_BUCKET ? creds.public : creds.gated;
  const to = target.bucket === env.R2_BUCKET ? creds.public : creds.gated;

  const got = await s3(from, source.bucket, 'GET', source.key);
  if (got.status === 404) { log(`     source missing, skipping`); return 'missing'; }
  if (!got.ok) { log(`     GET failed ${got.status}`); return 'failed'; }
  const body = Buffer.from(await got.arrayBuffer());
  const contentType = got.headers.get('content-type') ?? 'application/octet-stream';

  /* `x-amz-meta-sha256` is how the pipeline recognises an object it has already uploaded: before
     writing, it reads this header back and skips when the hash matches the local file. An earlier
     version of this copy did not carry it, so every moved object looked brand new — the first
     pipeline run after the staging re-key re-uploaded all 16 files instead of skipping them. On
     production that is the entire library, including a 380 MB video, for nothing.

     Set from the bytes actually copied rather than forwarded from the source, so this also repairs
     an object whose metadata was missing or wrong. */
  const bodyHash = sha256hex(body);
  const put = await s3(to, target.bucket, 'PUT', target.key, body, {
    'content-type': contentType,
    'x-amz-meta-sha256': bodyHash,
    // Gated bytes are only ever served through the Worker, which sets its own Cache-Control;
    // this is what a direct read would see, and `private` is the honest value for them.
    'cache-control': target.bucket === env.R2_BUCKET
      ? 'public, max-age=31536000, immutable'
      : 'private, max-age=31536000, immutable',
  });
  if (!put.ok) { log(`     PUT failed ${put.status} ${await put.text()}`); return 'failed'; }
  return bodyHash;
}

async function sbGet(query) {
  const out = [];
  for (let offset = 0; ; offset += 1000) {
    const res = await retryFetch(`${REST}${query}${query.includes('?') ? '&' : '?'}limit=1000&offset=${offset}`,
      { headers: sbHeaders });
    if (!res.ok) throw new Error(`${query}: ${res.status} ${await res.text()}`);
    const page = await res.json();
    out.push(...page);
    if (page.length < 1000) return out;
  }
}

/** Which bucket a stored URL points at. Public domain -> public bucket; anything else is gated. */
function bucketOf(url) {
  return url.startsWith(env.R2_PUBLIC_DOMAIN) ? env.R2_BUCKET : GATED_BUCKET;
}
function keyOf(url) {
  try { return decodeURIComponent(new URL(stripVersion(url)).pathname.replace(/^\/+/, '')) || null; }
  catch { return null; }
}

main().catch(e => { console.error('\n  FAILED:', e.message, '\n'); process.exit(1); });
