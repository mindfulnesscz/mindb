import { supabase } from '../lib/supabase'
import { reportError } from '../lib/reportError'

export async function fetchMyRating(assetId: string, userId: string): Promise<number> {
  if (!supabase) return 0

  const { data, error } = await (supabase as any)
    .from('ratings')
    .select('value')
    .eq('asset_id', assetId)
    .eq('user_id', userId)
    .limit(1)
    .maybeSingle()

  if (error) {
    reportError('feedback.ratingService.fetchMyRating', error)
    return 0
  }

  return (data as { value: number } | null)?.value ?? 0
}

export async function upsertRating(
  assetId: string,
  userId: string,
  value: number,
): Promise<void> {
  if (!supabase) throw new Error('Supabase not configured')

  const { error } = await (supabase as any)
    .from('ratings')
    .upsert(
      { asset_id: assetId, user_id: userId, value },
      { onConflict: 'asset_id,user_id' },
    )

  if (error) throw new Error(error.message)
}
