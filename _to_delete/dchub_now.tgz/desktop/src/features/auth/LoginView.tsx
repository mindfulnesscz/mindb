import { useState, type FormEvent } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useEnvironmentStore } from '../../store/environmentStore';
import { makeEnvironment, saveEnvironments, validateAnonKey } from '../../services/environmentService';
import {
  initAuthClient, checkEmail, sendMagicLink,
  waitForMagicLink, loadProfile, signOut, DESKTOP_ROLES,
} from '../../services/authService';
import css from './LoginView.module.css';

type Step = 'email' | 'checking' | 'waiting' | 'server';

/** Full-screen gate shown until a staff (editor/admin) session exists.
 * Magic-link only: email → staff pre-check → OTP mail → the user clicks the
 * link in their browser → loopback callback completes the PKCE exchange. */
export function LoginView() {
  const { status, server, setServer, setStatus, setProfile } = useAuthStore();
  const { environments, activeEnvId, setEnvironments, setActiveEnvId } = useEnvironmentStore();
  const [step, setStep]   = useState<Step>(server ? 'email' : 'server');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const [serverUrl, setServerUrl]   = useState(server?.url ?? '');
  const [serverKey, setServerKey]   = useState(server?.anonKey ?? '');
  const [serverName, setServerName] = useState(
    environments.find(e => e.id === activeEnvId)?.name ?? '',
  );

  /** Sign into a different environment — or create a new one via the
   * sentinel option. App.tsx reacts to the active-env change and re-auths
   * (a cached session for that environment skips the magic link entirely). */
  async function handleEnvChange(value: string) {
    if (value === '__new__') {
      const env = makeEnvironment({ name: 'New environment' });
      const list = [...environments, env];
      await saveEnvironments({ activeId: env.id, list });
      setEnvironments(list);
      setActiveEnvId(env.id);
      setServerUrl('');
      setServerKey('');
      setServerName('');
      setStep('server');
      return;
    }
    if (value === activeEnvId) return;
    await saveEnvironments({ activeId: value, list: environments });
    setActiveEnvId(value);
    const env = environments.find(e => e.id === value);
    setServerUrl(env?.supabaseUrl ?? '');
    setServerKey(env?.anonKey ?? '');
    setStatus('booting');
  }

  async function handleServerSave(e: FormEvent) {
    e.preventDefault();
    const url = serverUrl.trim().replace(/\/+$/, '');
    const anonKey = serverKey.trim();
    if (!url || !anonKey) return;
    const keyError = validateAnonKey(anonKey);
    if (keyError) { setError(keyError); return; }
    setError('');

    // The server config IS an environment: update the active one, or create
    // the first. Further environments come from "+ Add environment…" above.
    const fallbackName = url.includes('localhost') || url.includes('127.0.0.1') ? 'Local' : 'Production';
    const name = serverName.trim() || fallbackName;
    const active = environments.find(e2 => e2.id === activeEnvId);
    const created = active ? null : makeEnvironment({ name, supabaseUrl: url, anonKey });
    const list = active
      ? environments.map(e2 => e2.id === active.id ? { ...e2, name, supabaseUrl: url, anonKey } : e2)
      : [...environments, created!];
    const envId = created ? created.id : activeEnvId;
    await saveEnvironments({ activeId: envId, list });
    setEnvironments(list);
    setActiveEnvId(envId);

    const config = { url, anonKey };
    initAuthClient(config);
    setServer(config);
    setStatus('signedOut');
    setError('');
    setStep('email');
  }

  async function handleEmailSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = email.trim().toLowerCase();
    if (!trimmed) return;
    setError('');
    setStep('checking');
    try {
      const type = await checkEmail(trimmed);
      if (type !== 'staff') {
        setError('The desktop app is restricted to Sotto staff (editor/admin).');
        setStep('email');
        return;
      }
      await sendMagicLink(trimmed);
      setStep('waiting');
      const session = await waitForMagicLink();
      if (!session) throw new Error('Sign-in did not complete.');
      const profile = await loadProfile();
      if (!DESKTOP_ROLES.includes(profile.role)) {
        await signOut();
        setError(`Role "${profile.role}" cannot operate the desktop app.`);
        setStep('email');
        setStatus('signedOut');
        return;
      }
      setProfile(profile);
      setStatus('signedIn');
    } catch (err) {
      setError(String(err instanceof Error ? err.message : err));
      setStep('email');
    }
  }

  return (
    <div className={css.screen}>
      <form
        className={css.card}
        onSubmit={step === 'server' ? handleServerSave : handleEmailSubmit}
      >
        <h1 className={css.brand}>Sotto</h1>

        {step === 'server' ? (
          <>
            <p className={css.sub}>
              Connect this app to your Sotto server. Both values come from your
              administrator (or `supabase status` for the local stack).
            </p>
            <label className={css.label}>Environment name</label>
            <input
              className={css.input}
              placeholder="Production / Staging / Local"
              value={serverName}
              onChange={e => setServerName(e.target.value)}
            />
            <label className={css.label}>Server URL</label>
            <input
              className={css.input}
              placeholder="https://your-project.supabase.co"
              value={serverUrl}
              onChange={e => setServerUrl(e.target.value)}
            />
            <label className={css.label}>Anon key</label>
            <input
              className={css.input}
              placeholder="sb_publishable_…"
              value={serverKey}
              onChange={e => setServerKey(e.target.value)}
            />
            {error && <p className={css.error}>{error}</p>}
            <button className={css.button} type="submit" disabled={!serverUrl.trim() || !serverKey.trim()}>
              Save & continue
            </button>
          </>
        ) : step === 'waiting' ? (
          <>
            <p className={css.sub}>
              We sent a sign-in link to <strong>{email.trim()}</strong>.
              Open it in your browser and select Continue — this window will unlock automatically.
            </p>
            <div className={css.waiting}>
              <div className={css.spinner} />
              Waiting for you to click the link…
            </div>
            <button type="button" className={css.linkButton} onClick={() => { setStep('email'); setError(''); }}>
              Use a different email
            </button>
          </>
        ) : (
          <>
            <p className={css.sub}>
              Sign in to operate the pipeline. {status === 'denied'
                ? 'Your previous session was not authorized.'
                : 'Staff access only.'}
            </p>
            {environments.length > 0 && (
              <>
                <label className={css.label}>Environment</label>
                <select
                  className={css.input}
                  value={activeEnvId ?? ''}
                  onChange={e => { handleEnvChange(e.target.value).catch(err => setError(String(err))); }}
                >
                  {environments.map(e => (
                    <option key={e.id} value={e.id}>{e.name || e.supabaseUrl || 'Unnamed'}</option>
                  ))}
                  <option value="__new__">+ Add environment…</option>
                </select>
              </>
            )}
            <label className={css.label}>Email</label>
            <input
              className={css.input}
              type="email"
              placeholder="you@disruptcollective.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              autoFocus
            />
            {error && <p className={css.error}>{error}</p>}
            <button className={css.button} type="submit" disabled={step === 'checking' || !email.trim()}>
              {step === 'checking' ? 'Checking…' : 'Send sign-in link'}
            </button>
            <button type="button" className={css.linkButton} onClick={() => setStep('server')}>
              Configure server
            </button>
          </>
        )}
      </form>
    </div>
  );
}
