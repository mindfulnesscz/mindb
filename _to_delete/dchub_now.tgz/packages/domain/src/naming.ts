/* File/folder naming convention helpers */

/* Default folder convention markers (can be overridden by settings) */
export const DEFAULTS = {
  packagePrefix:  '[00] 📦',
  outFolder:      '[03] OUT',
  excludeMark:    '⦰',
};

export interface NamingSettings {
  packagePrefix: string;
  outFolder:     string;
  excludeMark:   string;
}

/** Exclusion is opt-out: everything is in scope unless it carries the exclude mark. */
export function shouldSkipName(name: string, s: NamingSettings): boolean {
  if (name.startsWith('~$')) return true;
  if (name.includes('[99]')) return true;
  return name.includes(s.excludeMark);
}

/** Strip optional `[NN] ` workflow prefix (migration / Vocabulary leave plain OUT). */
export function stripWorkflowPrefix(name: string): string {
  return name.replace(/^\[\d+\]\s*/, '').trim();
}

/**
 * Package folder match. Settings may store just `📦` while disks still use
 * `[00] 📦 Name` — require the configured marker after stripping `[NN] `, not
 * a brittle startsWith on the raw name.
 */
export function isPackageFolder(name: string, s: NamingSettings): boolean {
  const prefix = (s.packagePrefix || '').trim();
  if (!prefix) return false;
  if (name.startsWith(prefix)) return true;
  const strippedName = stripWorkflowPrefix(name);
  const strippedPrefix = stripWorkflowPrefix(prefix);
  if (strippedPrefix && strippedName.startsWith(strippedPrefix)) return true;
  if (strippedName.startsWith(prefix)) return true;
  // Prefix set to `[00] 📦` but folder is `📦 Name`
  if (strippedPrefix && name.startsWith(strippedPrefix)) return true;
  return false;
}

/**
 * OUT folder match — exact, or after stripping `[03] ` so settings `[03] OUT`
 * still match a migrated `OUT` directory (and the reverse).
 */
export function isOutFolder(name: string, s: NamingSettings): boolean {
  const want = stripWorkflowPrefix(s.outFolder || 'OUT').toLowerCase();
  const got  = stripWorkflowPrefix(name).toLowerCase();
  return got === want || got === 'out';
}

export function isPublishableFile(name: string): boolean {
  return name.includes('.') && !name.startsWith('.');
}

export function isThumbFile(stem: string): boolean {
  return stem.includes('-thumb');
}

/**
 * A generated preview artifact sitting beside an asset — either the `<stem>-thumb.webp` sidecar or
 * the `<stem>-thumb/` folder of per-page previews.
 *
 * Use this on EVERY directory entry a walker sees, not just the files. The name matches both cases
 * on purpose, which is why the previews folder is called `<stem>-thumb`: existing walkers already
 * excluded `-thumb`, so the folder inherits that. But the exclusion has to be applied BEFORE
 * branching on file-vs-directory. A walker that only checks files will descend into
 * `<stem>-thumb/` and collect `001.webp` as an asset — the page names deliberately do not contain
 * `-thumb`, so nothing downstream catches it, and the page previews would be published as assets,
 * synced to the DAM, and given thumbnails of their own.
 */
export function isPreviewArtifact(name: string): boolean {
  return name.includes('-thumb');
}
