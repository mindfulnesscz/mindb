# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> signed in >> the gallery lists the client’s published asset
- Location: e2e/smoke.spec.ts:63:3

# Error details

```
Error: sign-in failed: {"code":400,"error_code":"invalid_credentials","msg":"Invalid login credentials"}
```

# Test source

```ts
  34  | export const FIXTURE_ASSET_NAME = 'Smoke Test Deck';
  35  | 
  36  | /* A 1×1 transparent PNG, inline.
  37  |  *
  38  |  * The asset needs SOME thumbnail for the lightbox to be reachable — the preview is a button gated on
  39  |  * `thumbnailUrl`. A data URI rather than a CDN URL because this suite must not depend on R2, on the
  40  |  * `cdn-gate` Worker, or on a network at all: the routing behaviour under test is the same whatever the
  41  |  * bytes are, and a remote image would make the run fail for a reason unrelated to the app. */
  42  | export const FIXTURE_THUMB =
  43  |   'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==';
  44  | 
  45  | const svc = {
  46  |   apikey: SERVICE_KEY,
  47  |   Authorization: `Bearer ${SERVICE_KEY}`,
  48  |   'Content-Type': 'application/json',
  49  | };
  50  | 
  51  | /** True only when PostgREST in the full local stack answers successfully. */
  52  | export async function stackIsUp(): Promise<boolean> {
  53  |   try {
  54  |     const res = await fetch(`${API}/rest/v1/`, { headers: { apikey: ANON_KEY } });
  55  |     return res.ok;
  56  |   } catch {
  57  |     return false;
  58  |   }
  59  | }
  60  | 
  61  | export async function createFixtureTenant(): Promise<{ assetId: string }> {
  62  |   await destroyFixtureTenant();
  63  | 
  64  |   const client = await fetch(`${API}/rest/v1/clients`, {
  65  |     method: 'POST',
  66  |     headers: { ...svc, Prefer: 'return=minimal' },
  67  |     body: JSON.stringify({
  68  |       id: FIXTURE_CLIENT_ID,
  69  |       name: 'E2E Smoke (safe to delete)',
  70  |       slug: FIXTURE_SLUG,
  71  |       accent: '#2E6E4E',
  72  |       initials: 'ES',
  73  |     }),
  74  |   });
  75  |   if (!client.ok) throw new Error(`fixture client: ${await client.text()}`);
  76  | 
  77  |   // Published and client-visible, so it appears in the gallery for a signed-in member.
  78  |   const asset = await fetch(`${API}/rest/v1/assets`, {
  79  |     method: 'POST',
  80  |     headers: { ...svc, Prefer: 'return=representation' },
  81  |     body: JSON.stringify({
  82  |       client_id: FIXTURE_CLIENT_ID,
  83  |       shortcode: '(PRD)(SlD) Smoke',
  84  |       name: FIXTURE_ASSET_NAME,
  85  |       stable_id: 'ee000001',
  86  |       child_id: 'c1',
  87  |       status: 'published',
  88  |       perm: 'client',
  89  |       latest: true,
  90  |       thumbnail_url: FIXTURE_THUMB,
  91  |     }),
  92  |   });
  93  |   if (!asset.ok) throw new Error(`fixture asset: ${await asset.text()}`);
  94  |   const [row] = (await asset.json()) as Array<{ id: string }>;
  95  | 
  96  |   // The seeded admin must be a member of this client to see it in the gallery.
  97  |   await fetch(`${API}/rest/v1/client_members`, {
  98  |     method: 'POST',
  99  |     headers: { ...svc, Prefer: 'return=minimal' },
  100 |     body: JSON.stringify({
  101 |       user_id: '00000000-0000-0000-0000-0000000000ad',
  102 |       client_id: FIXTURE_CLIENT_ID,
  103 |     }),
  104 |   });
  105 | 
  106 |   return { assetId: row.id };
  107 | }
  108 | 
  109 | /** Deleting the client cascades its assets, memberships and feedback away. */
  110 | export async function destroyFixtureTenant(): Promise<void> {
  111 |   await fetch(`${API}/rest/v1/clients?id=eq.${FIXTURE_CLIENT_ID}`, {
  112 |     method: 'DELETE',
  113 |     headers: svc,
  114 |   });
  115 | }
  116 | 
  117 | /**
  118 |  * Sign in through the auth API and plant the session where the app looks for it.
  119 |  *
  120 |  * supabase-js stores under `sb-<project-ref>-auth-token`, deriving the ref from the URL's hostname. The
  121 |  * portal is configured with `localhost` while this file talks to `127.0.0.1`, and the exact derivation
  122 |  * is library-internal. Rather than depend on it, BOTH plausible keys are planted — an unused
  123 |  * localStorage entry costs nothing, and a wrong key would surface as "the app thinks it is signed out",
  124 |  * which reads like an application bug when it is a harness detail.
  125 |  *
  126 |  * `expectSignedIn` exists so that if this ever does break, it fails saying so.
  127 |  */
  128 | export async function signIn(page: Page): Promise<void> {
  129 |   const res = await fetch(`${API}/auth/v1/token?grant_type=password`, {
  130 |     method: 'POST',
  131 |     headers: { apikey: ANON_KEY, 'Content-Type': 'application/json' },
  132 |     body: JSON.stringify({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD }),
  133 |   });
> 134 |   if (!res.ok) throw new Error(`sign-in failed: ${await res.text()}`);
      |                      ^ Error: sign-in failed: {"code":400,"error_code":"invalid_credentials","msg":"Invalid login credentials"}
  135 |   const session = JSON.stringify(await res.json());
  136 | 
  137 |   await page.addInitScript(value => {
  138 |     for (const ref of ['localhost', '127']) {
  139 |       window.localStorage.setItem(`sb-${ref}-auth-token`, value as string);
  140 |     }
  141 |   }, session);
  142 | }
  143 | 
```